Highlands Readme

http://www.minecraftforum.net/topic/1602064-147146-forge-highlands-new-biomes-trees-and-more/

Thank you for downloading Highlands!
Description of the features of the mod and its biomes and trees can be found on the forum post.



Installation:
Client:
Download and install the latest recommended version of Minecraft Forge.
Drag and drop this .zip folder into your "mods" folder.
Run Minecraft and enjoy!
If you want to change some settings, run Minecraft once (without making a world), quit, then go to the config folder to edit the settings.

Server:
Download and install the latest recommended version of Minecraft Forge.
Drag and drop this .zip folder into your "mods" folder.
Run the server once to generate the settings file (located in config).
Change the worldtype of the server world to "HIGHLANDS" or "HIGHLANDS_LB" in the server.properties or change "Use Highlands in Default Worlds" to true in the settings.
Change any other settings you want in the server.properties and Highlands.cfg.
Start a new world on the server. You should be all set. Clients need Highlands as well to connect to the server.

To generate a map using Highlands:
If you want to use Highlands to generate a map to use on a server that does not have Highlands installed, change the settings so that "Highlands Wood and Leaves" and "Generate Small Plants" are false.  That way there will be no modded blocks in your world.  Then generate your world and fly around or use a program to generate new chunks.


Mod Compatibility:
Now with API support for Forestry, Thaumcraft, MineFactory, and Buildcraft!  credits to Sadris for work with the APIs.
Refer to the Minecraft Forum topic for up-to-date compatiblity information.
Post on the Minecraft Forum topic if you experience an error.  Please include your crash report and/or Forge log and a list of mods you have installed!


Settings information:
Biome Prefix - If you are using multiple biome mods, activate this so that there will be no duplicate names.

More Oceans - Adds more oceans to the world.  Try 100 or more for a world where almost every biome is an island.

Island Rarity - Reduces the chance of islands spawning in the ocean.  Also decreases the size of islands.  The exact formula is a bit confusing: if you add 14 to this number, then double it, then subtract 14, that will make exactly 1/2 the islands and islands 1/2 the size.

Biome Size - ranges from 0 to 15, each increase of one doubles the size of the biomes.  Default worldtype is 4, Large Biomes is 6.  Try a biome size of 5, it's a great happy medium.

Highlands Biomes in Default Worlds - Regularly, Highlands biomes only generate in their own worldtypes.  Enable this if you are using another biome mod, and use a Default or Large Biomes world.

Sky Colors - Not all biomes have custom sky colors but some do.  It is off by default because most people find the color change on borders annoying, but it's here as an option.

Highlands wood and leaves - not all trees have new wood and leaves, some have vanilla even with this setting true.  If false all trees will be made of the vanilla wood types.

Generate small plants - the small plants are blue flower, white flower, leafy fern, cattail, lavender, blueberry, raspberry, thornbush, cotton.

Generate biome-specific ores - see the Minecraft Forum topic for which ores spawn in which biomes.  If you are using Underground Biomes or Custom Ore Generation, you will want to turn this off. 

Mob Mod Compatiblilty - This can help Highlands become compatible with mods that add creatures and monsters.  It is NOT COMPATIBLE with DrZhark's CustomMobSpawner.  If you are using Mo Creatures, instead download and install the Mo Creatures settings file in the "Mod Compatiblity" section of the Highlands main post.

Safe Mode - Highlands uses a group of classes called Gen Layers to generate sub-biomes, improved oceans, and border biomes.  In rare cases your Minecraft client may get stuck on "Converting World" using these, so you may disable them by activating Safe Mode.  Biomes o' Plenty also uses Gen Layers so if you are using it or another mod that uses Gen Layers, you can turn this on for compatibility.


Please do not redistribute Highlands or use it in a publicly available modpack without my permission.  Private modpacks and modpacks used exclusively for a single public server and its clients are alright.



